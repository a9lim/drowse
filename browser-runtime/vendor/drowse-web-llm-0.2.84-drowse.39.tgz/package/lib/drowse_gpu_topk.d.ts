import type * as tvmjs from "@mlc-ai/web-runtime";
export declare function drowseSamplingTopKShader(capacity: number, merge: boolean): string;
export declare class DrowseGpuTopK {
    private readonly tvm;
    private kernels;
    constructor(tvm: tvmjs.Instance);
    select(probabilities: tvmjs.Tensor, count: number): [tvmjs.Tensor, tvmjs.Tensor];
    dispose(): void;
}
//# sourceMappingURL=drowse_gpu_topk.d.ts.map