import type * as tvmjs from "@mlc-ai/web-runtime";
export declare function drowseCurveControlShader(stride: number): string;
export declare function createDrowseCurveControlKernel(tvm: tvmjs.Instance, stride: number): tvmjs.PackedFunc;
//# sourceMappingURL=drowse_gpu_controls.d.ts.map