export declare const DROWSE_HOOK_ABI: "post-block-residual-v4";
export declare const DROWSE_EXACT_READOUT_ABI: "exact-readout-v1";
export interface DrowseRuntimeCapabilities {
    topK: boolean;
    forcedReplay: boolean;
    replayScoring: boolean;
    tokenizer: boolean;
    namedRoles: boolean;
    userSeatGeneration: boolean;
    sceneStitching: boolean;
}
export declare const DROWSE_READOUT_TOP_K = 8;
export interface DrowseSaeDictionary {
    hookAbi: typeof DROWSE_HOOK_ABI;
    bindingId: string;
    hiddenSize: number;
    runtimeLayerIndex: number;
    featureCount: number;
    activation: "relu" | "jump_relu";
    encoder: Float32Array;
    encoderBias: Float32Array;
    encoderThreshold: Float32Array;
    decoderBias: Float32Array;
}
export interface DrowseJlensDictionary {
    hookAbi: typeof DROWSE_HOOK_ABI;
    bindingId: string;
    hiddenSize: number;
    layerIndices: Int32Array;
    matrices: readonly Float32Array[];
}
export interface DrowseJlensTopTokenReadout {
    tokenIds: Int32Array;
    strength: Float32Array;
    centerOfMass: Float32Array;
    spread: Float32Array;
    fittedLayerCount: number;
    layerIndices: Int32Array;
    layerTokenIds: Int32Array;
    layerProbabilities: Float32Array;
}
export interface DrowseSaeTopFeatureReadout {
    featureIds: Int32Array;
    activations: Float32Array;
    runtimeLayerIndex: number;
    featureCount: number;
}
export interface DrowseMeasurementBundle {
    scalar?: Float32Array;
    geometry?: Float32Array;
    jlensTopTokens?: DrowseJlensTopTokenReadout;
    saeTopFeatures?: DrowseSaeTopFeatureReadout;
}
export interface DrowseStructuredHookProfile {
    schemaVersion: 3;
    id: "standard-v3";
    hookAbi: typeof DROWSE_HOOK_ABI;
    format: typeof DROWSE_STRUCTURED_HOOK_FORMAT;
    layerCount: number;
    hiddenSize: number;
    maxAffineGroups: number;
    maxRank: number;
    maxProbes: number;
    maxCurves: number;
    maxCurveNodes: number;
    maxIntrinsicDim: number;
    maxEmbedDim: number;
    curveParameterStride: number;
    maxComputeWorkgroupStorageSize: number;
    maxGeometryProbes: number;
    maxWhitenerRank: number;
    maxGeometryCandidates: number;
    geometryOutputStride: number;
    geometryFootRestarts: number;
    geometryFootIterations: number;
    geometryWarmRestarts: number;
    geometryWarmIterations: number;
    requiredMaxStorageBuffersPerShaderStage: number;
    geometryKernelStorageBindings: number;
    geometryHeaderStride: number;
    geometryPayloadElements: number;
    exactReadoutAbiVersion: 1;
    exactReadoutAbi: typeof DROWSE_EXACT_READOUT_ABI;
    readoutTopK: number;
    maxSaeFeaturesPerChunk: number;
}
export interface DrowseRankOneProgram {
    hookAbi: typeof DROWSE_HOOK_ABI;
    hiddenSize: number;
    layerCount: number;
    enabled: Uint32Array;
    basis: Float32Array;
    neutral: Float32Array;
    target: Float32Array;
    along: Float32Array;
    collapse: Float32Array;
    probeBasis: Float32Array;
    probeNeutral: Float32Array;
}
export declare const DROWSE_STRUCTURED_HOOK_FORMAT_V2: "drowse-structured-v2";
export declare const DROWSE_STRUCTURED_HOOK_FORMAT: "drowse-structured-v3";
export type DrowseStructuredHookFormat = typeof DROWSE_STRUCTURED_HOOK_FORMAT_V2 | typeof DROWSE_STRUCTURED_HOOK_FORMAT;
export declare const DROWSE_STRUCTURED_MAX_AFFINE_GROUPS = 4;
export declare const DROWSE_STRUCTURED_MAX_RANK = 8;
export declare const DROWSE_STRUCTURED_MAX_PROBES = 8;
export declare const DROWSE_STRUCTURED_MAX_CURVES = 4;
export declare const DROWSE_STRUCTURED_MAX_CURVE_NODES = 32;
export declare const DROWSE_STRUCTURED_MAX_INTRINSIC_DIM = 4;
export declare const DROWSE_STRUCTURED_MAX_EMBED_DIM = 8;
export declare const DROWSE_STRUCTURED_CURVE_PARAMETER_STRIDE = 671;
export declare const DROWSE_STRUCTURED_MAX_GEOMETRY_PROBES = 8;
export declare const DROWSE_STRUCTURED_MAX_WHITENER_RANK = 96;
export declare const DROWSE_STRUCTURED_MAX_GEOMETRY_CANDIDATES = 33;
export declare const DROWSE_STRUCTURED_GEOMETRY_OUTPUT_STRIDE = 41;
export declare const DROWSE_STRUCTURED_GEOMETRY_FOOT_RESTARTS = 3;
export declare const DROWSE_STRUCTURED_GEOMETRY_FOOT_ITERATIONS = 12;
export declare const DROWSE_STRUCTURED_GEOMETRY_WARM_RESTARTS = 2;
export declare const DROWSE_STRUCTURED_GEOMETRY_WARM_ITERATIONS = 4;
export declare const DROWSE_STRUCTURED_GEOMETRY_HEADER_STRIDE = 7;
export declare const DROWSE_STRUCTURED_GEOMETRY_KERNEL_STORAGE_BINDINGS = 8;
export declare const DROWSE_STRUCTURED_REQUIRED_MAX_STORAGE_BUFFERS_PER_SHADER_STAGE = 8;
export declare const DROWSE_STRUCTURED_PROFILE_SCHEMA_VERSION: 3;
export declare const DROWSE_STRUCTURED_PROFILE_ID: "standard-v3";
export declare const DROWSE_STRUCTURED_PROFILE_MAGIC = 1396788044;
export declare const DROWSE_STRUCTURED_PROFILE_DESCRIPTOR_LENGTH = 31;
export declare const DROWSE_EXACT_READOUT_ABI_VERSION: 1;
export declare const DROWSE_EXACT_READOUT_MAX_SAE_FEATURES_PER_CHUNK = 16384;
export declare const DROWSE_STRUCTURED_MIN_COMPUTE_WORKGROUP_STORAGE_SIZE: number;
export declare function drowseGeometryPayloadElements(layerCount: number, hiddenSize: number): number;
export declare function decodeDrowseStructuredHookProfile(values: ArrayLike<number>, expectedLayerCount: number, expectedHiddenSize: number): DrowseStructuredHookProfile;
export interface DrowseStructuredProgram {
    hookAbi: typeof DROWSE_HOOK_ABI;
    format: DrowseStructuredHookFormat;
    hiddenSize: number;
    layerCount: number;
    affineActive: Uint32Array;
    affineBasis: Float32Array;
    affineNeutral: Float32Array;
    affineTarget: Float32Array;
    affineAlong: Float32Array;
    affineKappa: Float32Array;
    probeKind: Uint32Array;
    probeDirection: Float32Array;
    probeBias: Float32Array;
    probeThreshold: Float32Array;
    curveActive: Uint32Array;
    curveRank: Uint32Array;
    curveIntrinsicDim: Uint32Array;
    curveEmbedDim: Uint32Array;
    curveNodeCount: Uint32Array;
    curveBasis: Float32Array;
    curveNeutral: Float32Array;
    curveNodeParameters: Float32Array;
    curveRbfWeights: Float32Array;
    curvePolynomial: Float32Array;
    curveCoordinateOffset: Float32Array;
    curveCoordinateScale: Float32Array;
    curveOrigin: Float32Array;
    curveTarget: Float32Array;
    curveAlong: Float32Array;
    curveOnto: Float32Array;
    curveBounds: Float32Array;
    curveAxisPeriodic: Uint32Array;
    curveAxisPeriod: Float32Array;
    curveSigmaPresent: Uint32Array;
    curveSigmaRbfWeights: Float32Array;
    curveSigmaPolynomial: Float32Array;
    curveDamping: Float32Array;
    curveDomainKind?: Uint32Array;
    whitenerRank?: Uint32Array;
    whitenerRidge?: Float32Array;
    whitenerBasis?: Float32Array;
    whitenerCorrection?: Float32Array;
    geometryActive?: Uint32Array;
    geometryKind?: Uint32Array;
    geometryRank?: Uint32Array;
    geometryIntrinsicDim?: Uint32Array;
    geometryCandidateCount?: Uint32Array;
    geometryCurveNodeCount?: Uint32Array;
    geometryDomainKind?: Uint32Array;
    geometryMean?: Float32Array;
    geometryInverseMean?: Float32Array;
    geometryBasis?: Float32Array;
    geometryGramInverse?: Float32Array;
    geometryCholesky?: Float32Array;
    geometryNodeWhite?: Float32Array;
    geometryCoordMap?: Float32Array;
    geometryCoordBias?: Float32Array;
    geometryCurveParameters?: Float32Array;
    geometryCurveNodeCoords?: Float32Array;
    geometryCurveNodeValues?: Float32Array;
    geometryFeet?: Float32Array;
    jLensBindingId?: string;
    jLensLayerIndices?: Int32Array;
    jLensReadoutLayerIndices?: Int32Array;
    jLensTokenIds?: Int32Array;
    saeBindingId?: string;
}
export declare function packDrowseCurveParameters(program: DrowseStructuredProgram): Float32Array;
export declare function updatePackedDrowseCurveActive(packed: Float32Array, active: Uint32Array): void;
export declare function packDrowseGeometryHeader(program: DrowseStructuredProgram): Uint32Array;
export declare function packDrowseGeometryPayload(program: DrowseStructuredProgram): Float32Array;
export interface DrowseResidualCapture {
    layerCount: number;
    positionCount: number;
    hiddenSize: number;
    positions: number[];
    values: Float32Array;
}
export interface DrowseRankOneResidualCaptureV1 extends DrowseResidualCapture {
    abiVersion: 1;
    measurements: Float32Array;
}
export interface DrowseCaptureMessage {
    role: "system" | "user" | "assistant";
    content: string;
    roleName?: string;
}
export interface DrowseCaptureRow {
    system: string;
    messages: DrowseCaptureMessage[];
}
export interface DrowsePreparedCaptureRow {
    inputIds: number[];
    position: number;
}
export declare function validateDrowseCaptureRows(rows: DrowseCaptureRow[], specialTokenIds: number[]): void;
export declare function validateDrowseCapturePositions(positions: number[], tokenCount: number): void;
export declare function validateDrowseRankOneProgram(program: DrowseRankOneProgram, expectedHiddenSize: number, expectedLayerCount: number): void;
export declare function validateDrowseSaeDictionary(dictionary: DrowseSaeDictionary, hiddenSize: number, layerCount: number): void;
export declare function validateDrowseJlensDictionary(dictionary: DrowseJlensDictionary, hiddenSize: number, layerCount: number): void;
export declare function validateDrowseStructuredProgram(program: DrowseStructuredProgram, expectedHiddenSize: number, expectedLayerCount: number): void;
//# sourceMappingURL=drowse.d.ts.map