import { AppConfig, ChatOptions } from "./config";
import { InitProgressReport, LogLevel } from "./types";
import { ChatCompletionRequestStreaming, ChatCompletionRequestNonStreaming, ChatCompletion, ChatCompletionChunk, CompletionCreateParamsNonStreaming, CompletionCreateParamsStreaming, Completion, EmbeddingCreateParams, CreateEmbeddingResponse } from "./openai_api_protocols/index";
import { PolytheticCaptureRow, PolytheticPreparedCaptureRow, PolytheticRankOneProgram, PolytheticStructuredProgram, PolytheticResidualCapture, PolytheticRuntimeCapabilities, PolytheticStructuredHookProfile, PolytheticSaeDictionary, PolytheticJlensDictionary, PolytheticJlensTopTokenReadout, PolytheticMeasurementBundle, PolytheticSaeTopFeatureReadout } from "./polythetic";
/**
 * Message kind used by worker
 */
type RequestKind = "reload" | "runtimeStatsText" | "interruptGenerate" | "unload" | "resetChat" | "getMaxStorageBufferBindingSize" | "getGPUVendor" | "forwardTokensAndSample" | "supportsPolytheticRankOneHooks" | "supportsPolytheticStructuredHooks" | "supportsPolytheticCurvedHooks" | "supportsPolytheticResidualCapture" | "supportsPolytheticRankOneResidualCaptureV1" | "getPolytheticRuntimeCapabilities" | "getPolytheticStructuredHookProfile" | "tokenizePolytheticText" | "decodePolytheticTokens" | "preparePolytheticCaptureRows" | "capturePolytheticResiduals" | "capturePolytheticRankOneResidualsV1" | "setPolytheticRankOneProgram" | "setPolytheticStructuredProgram" | "updatePolytheticStructuredControls" | "clearPolytheticRankOneProgram" | "setPolytheticSaeDictionary" | "clearPolytheticSaeDictionary" | "setPolytheticJlensDictionary" | "clearPolytheticJlensDictionary" | "readPolytheticMeasurementBundle" | "readPolytheticJlensTopTokens" | "readPolytheticSaeTopFeatures" | "readPolytheticMeasurements" | "readPolytheticGeometryMeasurements" | "resolvePolytheticJlensTokenDirections" | "chatCompletionNonStreaming" | "completionNonStreaming" | "embedding" | "getMessage" | "chatCompletionStreamInit" | "completionStreamInit" | "completionStreamNextChunk" | "customRequest" | "keepAlive" | "setLogLevel" | "setAppConfig";
export interface ReloadParams {
    modelId: string[];
    chatOpts?: ChatOptions[];
}
export interface ResetChatParams {
    keepStats: boolean;
    modelId?: string;
}
export interface GetMessageParams {
    modelId?: string;
}
export interface RuntimeStatsTextParams {
    modelId?: string;
}
export interface ForwardTokensAndSampleParams {
    inputIds: Array<number>;
    isPrefill: boolean;
    modelId?: string;
}
export interface PolytheticModelParams {
    modelId?: string;
}
export interface TokenizePolytheticTextParams extends PolytheticModelParams {
    text: string;
}
export interface DecodePolytheticTokensParams extends PolytheticModelParams {
    tokenIds: number[];
}
export interface SetPolytheticRankOneProgramParams extends PolytheticModelParams {
    program: PolytheticRankOneProgram;
}
export interface SetPolytheticStructuredProgramParams extends PolytheticModelParams {
    program: PolytheticStructuredProgram;
}
export interface UpdatePolytheticStructuredControlsParams extends PolytheticModelParams {
    affineActive: Uint32Array;
    curveActive?: Uint32Array;
}
export interface SetPolytheticSaeDictionaryParams extends PolytheticModelParams {
    dictionary: PolytheticSaeDictionary;
}
export interface SetPolytheticJlensDictionaryParams extends PolytheticModelParams {
    dictionary: PolytheticJlensDictionary;
}
export interface ResolvePolytheticJlensTokenDirectionsParams extends PolytheticModelParams {
    bindingId: string;
    layerIndices: number[];
    tokenIds: number[];
}
export interface CapturePolytheticResidualsParams extends PolytheticModelParams {
    inputIds: number[];
    positions: number[];
}
export interface CapturePolytheticRankOneResidualsV1Params extends CapturePolytheticResidualsParams {
    program: PolytheticRankOneProgram;
}
export interface PreparePolytheticCaptureRowsParams extends PolytheticModelParams {
    rows: PolytheticCaptureRow[];
    specialTokenIds: number[];
}
export interface ChatCompletionNonStreamingParams {
    request: ChatCompletionRequestNonStreaming;
    modelId: string[];
    chatOpts?: ChatOptions[];
}
export interface ChatCompletionStreamInitParams {
    request: ChatCompletionRequestStreaming;
    selectedModelId: string;
    modelId: string[];
    chatOpts?: ChatOptions[];
}
export interface CompletionNonStreamingParams {
    request: CompletionCreateParamsNonStreaming;
    modelId: string[];
    chatOpts?: ChatOptions[];
}
export interface CompletionStreamInitParams {
    request: CompletionCreateParamsStreaming;
    selectedModelId: string;
    modelId: string[];
    chatOpts?: ChatOptions[];
}
export interface EmbeddingParams {
    request: EmbeddingCreateParams;
    modelId: string[];
    chatOpts?: ChatOptions[];
}
export interface CompletionStreamNextChunkParams {
    selectedModelId: string;
}
export interface CustomRequestParams {
    requestName: string;
    requestMessage: string;
}
export type MessageContent = ReloadParams | ResetChatParams | GetMessageParams | RuntimeStatsTextParams | ForwardTokensAndSampleParams | PolytheticModelParams | TokenizePolytheticTextParams | DecodePolytheticTokensParams | SetPolytheticRankOneProgramParams | SetPolytheticStructuredProgramParams | UpdatePolytheticStructuredControlsParams | SetPolytheticSaeDictionaryParams | SetPolytheticJlensDictionaryParams | ResolvePolytheticJlensTokenDirectionsParams | CapturePolytheticResidualsParams | CapturePolytheticRankOneResidualsV1Params | PreparePolytheticCaptureRowsParams | ChatCompletionNonStreamingParams | ChatCompletionStreamInitParams | CompletionNonStreamingParams | CompletionStreamInitParams | EmbeddingParams | CompletionStreamNextChunkParams | CustomRequestParams | InitProgressReport | LogLevel | string | null | number | boolean | Float32Array | number[] | PolytheticRuntimeCapabilities | PolytheticStructuredHookProfile | PolytheticResidualCapture | PolytheticPreparedCaptureRow[] | PolytheticMeasurementBundle | PolytheticJlensTopTokenReadout | PolytheticSaeTopFeatureReadout | ChatCompletion | ChatCompletionChunk | CreateEmbeddingResponse | Completion | AppConfig | void;
/**
 * The message used in exchange between worker
 * and the main thread.
 */
export type WorkerRequest = {
    kind: RequestKind;
    uuid: string;
    content: MessageContent;
};
type HeartbeatWorkerResponse = {
    kind: "heartbeat";
    uuid: string;
};
type OneTimeWorkerResponse = {
    kind: "return" | "throw";
    uuid: string;
    content: MessageContent;
};
type InitProgressWorkerResponse = {
    kind: "initProgressCallback";
    uuid: string;
    content: InitProgressReport;
};
export type WorkerResponse = OneTimeWorkerResponse | InitProgressWorkerResponse | HeartbeatWorkerResponse;
export {};
//# sourceMappingURL=message.d.ts.map