import type { GPUDeviceDetectOutput } from "@mlc-ai/web-runtime";
export declare function requestGPUDeviceFromAdapter(adapter: GPUAdapter): Promise<GPUDeviceDetectOutput>;
//# sourceMappingURL=gpu.d.ts.map