import * as tvmjs from "@mlc-ai/web-runtime";
import { Tokenizer } from "@mlc-ai/web-tokenizers";
import { ChatConfig, GenerationConfig, Role } from "./config";
import { Conversation } from "./conversation";
import { LogitProcessor, LatencyBreakdown } from "./types";
import { ChatCompletionFinishReason, ChatCompletionTokenLogprob, PolytheticGenerationFinishReason, PolytheticReplayLogprob } from "./openai_api_protocols/index";
import { PolytheticRankOneProgram, PolytheticStructuredProgram, PolytheticCaptureRow, PolytheticPreparedCaptureRow, PolytheticRankOneResidualCaptureV1, PolytheticResidualCapture, PolytheticRuntimeCapabilities, PolytheticStructuredHookProfile, PolytheticSaeDictionary, PolytheticJlensDictionary, PolytheticJlensTopTokenReadout, PolytheticMeasurementBundle, PolytheticSaeTopFeatureReadout } from "./polythetic";
export type PolytheticJlensBufferLimits = {
    maxBufferSize: number;
    maxStorageBufferBindingSize: number;
};
export type PolytheticJlensChunkPlan = {
    layerIds: number[];
    byteLength: number;
};
export declare const POLYTHETIC_JLENS_MAX_CHUNK_BYTES: number;
export declare const POLYTHETIC_SAE_MAX_CHUNK_BYTES: number;
export declare const POLYTHETIC_SAE_MAX_FEATURES_PER_CHUNK = 16384;
export type PolytheticSaeChunkPlan = {
    featureOffset: number;
    featureCount: number;
    paddedFeatureCount: number;
    encoderByteLength: number;
};
export declare function planPolytheticSaeChunks(hiddenSize: number, featureCount: number, limits: PolytheticJlensBufferLimits): PolytheticSaeChunkPlan[];
export declare function planPolytheticJlensChunks(layerIds: readonly number[], hiddenSize: number, limits: PolytheticJlensBufferLimits): PolytheticJlensChunkPlan[];
export interface PolytheticSamplerResult {
    sampledTokenId: number;
    sampledLogprob: number;
    selectedLogprobs: PolytheticReplayLogprob[];
    argmax: PolytheticReplayLogprob;
    topLogprobs: PolytheticReplayLogprob[];
    entropyNats: number;
    perplexity: number;
}
export declare const POLYTHETIC_DEFAULT_TOP_K = 1024;
export declare function effectivePolytheticTopK(topK: number, vocabSize: number): number;
export declare function samplePolytheticTopKTopP(sortedProbabilities: Float32Array, sortedTokenIds: Int32Array, topP: number, topK: number, uniformSample: number, selectedTokenIds?: readonly number[]): PolytheticSamplerResult;
export declare class LLMChatPipeline {
    private config;
    private tokenizer;
    private tvm;
    private device;
    private vm;
    private prefill;
    private decoding;
    private polytheticPrefill?;
    private polytheticDecoding?;
    private polytheticStructuredPrefill?;
    private polytheticStructuredDecoding?;
    private polytheticCurvedPrefill?;
    private polytheticCurvedDecoding?;
    private polytheticGeometryPrefill?;
    private polytheticGeometryDecoding?;
    private polytheticCapturePrefill?;
    private polytheticCaptureDecoding?;
    private polytheticRankOneCapturePrefillV1?;
    private polytheticRankOneCaptureDecodingV1?;
    private polytheticJlensReadout?;
    private polytheticJlensReadoutAccumulate?;
    private polytheticJlensReadoutTopK?;
    private polytheticJlensDirections?;
    private polytheticSaeReadoutAccumulate?;
    private polytheticSaeJumpReluReadoutAccumulate?;
    private polytheticHookProfile?;
    private resolvedModelABI;
    private kvStateKind;
    private image_embed;
    private embed;
    private fapplyBitmask;
    private fapplyPenalty;
    private fapplyLogitBias;
    private fsoftmaxWithTemperature;
    private fsampleWithTopP;
    private fargsortProbs;
    private fclearKVCaches;
    private fKVCacheAddSequence;
    private fKVCacheRemoveSequence;
    private fKVCacheBeginForward;
    private fKVCacheEndForward;
    private fKVCacheEnableSlidingWindowForSeq;
    private params;
    private kvCache?;
    private rnnState?;
    private prefillLogitPositions?;
    private prefillLogitPositionHost;
    private maxHistorySize;
    private logitsOnCPU?;
    private polytheticProgram?;
    private polytheticStructuredProgram?;
    private polytheticStructuredMode?;
    private polytheticAffineAlongHost?;
    private polytheticCurveParametersHost?;
    private polytheticMeasurements?;
    private polytheticGeometryMeasurements?;
    private polytheticJlensChunks?;
    private polytheticJlensDictionary?;
    private polytheticJlensBufferLimits?;
    private polytheticJlensProbabilitiesHost?;
    private polytheticJlensTopTokensHost?;
    private polytheticPendingJlensReadback?;
    private polytheticSaeDictionary?;
    private polytheticSaeReadoutActive;
    private polytheticSaeTopFeaturesHost?;
    private polytheticPendingSaeReadback?;
    private polytheticMeasurementBundleHost?;
    private polytheticExactReadoutAttested;
    private polytheticProbeKindHost?;
    private filledKVCacheLength;
    private bosTokenId;
    private contextWindowSize;
    private slidingWindowSize;
    private attentionSinkSize;
    private prefillChunkSize;
    private resetStatsPerPrefill;
    private stopStr;
    private stopTokens;
    private outputMessage;
    private outputIds;
    private outputPrefix;
    private polytheticRawMessage;
    private stopTriggered;
    private finishReason;
    private polytheticFinishReason;
    private appearedTokensFreq;
    private imageDataCache;
    private conversation;
    private tokenLogprobArray;
    private decodingTotalTime;
    private decodingTotalTokens;
    private prefillTotalTime;
    private prefillTotalTokens;
    private curRoundDecodingTotalTokens;
    private curRoundPrefillTotalTokens;
    private curRoundDecodingTotalTime;
    private curRoundPrefillTotalTime;
    private curRoundSampledTokens;
    private curRoundPolytheticCompletionTokens;
    curRoundLatencyBreakdown: LatencyBreakdown;
    private logitProcessor?;
    private grammarMatcher?;
    private responseFormatCacheKey?;
    private xgTokenizerInfo?;
    private grammarCompiler?;
    private bitmaskSize;
    private fullVocabSize;
    private token_postproc_method;
    private prepend_space_in_encode;
    private curRoundGrammarInitTotalTime;
    private curRoundGrammarPerTokenTotalTime;
    private sampleIndices;
    private sampleIndicesDevice;
    private topPDevice;
    constructor(tvm: tvmjs.Instance, tokenizer: Tokenizer, config: ChatConfig, logitProcessor?: LogitProcessor, polytheticJlensBufferLimits?: PolytheticJlensBufferLimits);
    dispose(): void;
    supportsPolytheticRankOneHooks(): boolean;
    supportsPolytheticStructuredHooks(): boolean;
    supportsPolytheticCurvedHooks(): boolean;
    supportsPolytheticResidualCapture(): boolean;
    supportsPolytheticRankOneResidualCaptureV1(): boolean;
    getPolytheticRuntimeCapabilities(): PolytheticRuntimeCapabilities;
    getPolytheticStructuredHookProfile(): Promise<PolytheticStructuredHookProfile>;
    tokenizePolytheticText(text: string): number[];
    decodePolytheticTokens(tokenIds: readonly number[]): string;
    preparePolytheticCaptureRows(rows: PolytheticCaptureRow[], specialTokenIds: number[]): PolytheticPreparedCaptureRow[];
    capturePolytheticResiduals(inputIds: number[], positions: number[]): Promise<PolytheticResidualCapture>;
    capturePolytheticRankOneResidualsV1(inputIds: number[], positions: number[], program: PolytheticRankOneProgram): Promise<PolytheticRankOneResidualCaptureV1>;
    setPolytheticRankOneProgram(program: PolytheticRankOneProgram): void;
    setPolytheticStructuredProgram(program: PolytheticStructuredProgram): Promise<void>;
    updatePolytheticStructuredControls(affineActive: Uint32Array, curveActive?: Uint32Array): Promise<void>;
    setPolytheticSaeDictionary(dictionary: PolytheticSaeDictionary): Promise<void>;
    clearPolytheticSaeDictionary(): Promise<void>;
    setPolytheticJlensDictionary(dictionary: PolytheticJlensDictionary): Promise<void>;
    clearPolytheticJlensDictionary(): Promise<void>;
    readPolytheticJlensTopTokens(): Promise<PolytheticJlensTopTokenReadout | undefined>;
    readPolytheticSaeTopFeatures(): Promise<PolytheticSaeTopFeatureReadout | undefined>;
    clearPolytheticRankOneProgram(): void;
    readPolytheticMeasurementBundle(): Promise<PolytheticMeasurementBundle>;
    readPolytheticMeasurements(): Promise<Float32Array | undefined>;
    readPolytheticGeometryMeasurements(): Promise<Float32Array | undefined>;
    resolvePolytheticJlensTokenDirections(bindingId: string, layerIndices: readonly number[], tokenIds: readonly number[]): Promise<Float32Array>;
    private computePolytheticJlensProbabilities;
    private computePolytheticJlensProbabilitiesAndTopTokens;
    private uploadPolytheticJlensChunks;
    private uploadPolytheticSaeDictionary;
    private computePolytheticSaeTopFeatures;
    private materializePolytheticJlensReadback;
    private materializePolytheticSaeReadback;
    private disposePolytheticPendingJlensReadback;
    private disposePolytheticPendingSaeReadback;
    private disposePolytheticPendingReadbacks;
    private resetPolytheticReadbackState;
    private requirePolytheticTensorShape;
    private requirePolytheticJlensBufferLimits;
    private selectPolytheticJlensChunks;
    private requirePolytheticExactReadout;
    private requireModelDimension;
    private disposePolytheticProgram;
    private disposePolytheticJlensDictionary;
    private disposePolytheticSaeDictionary;
    /**
     * Get the current message.
     */
    getMessage(): string;
    /** Return the monotonically decoded generated tokens before stop-string trimming. */
    getPolytheticRawMessage(): string;
    /**
     * Reset the runtime statistics
     */
    resetRuntimeStats(): void;
    /**
     * Reset the chat history
     */
    resetChat(keepStats?: boolean): void;
    /**
     * Reset KV Cache
     */
    resetKVCache(): void;
    /**
     * @returns Whether stop is triggered.
     */
    stopped(): boolean;
    /**
     * @returns Finish reason; undefined if generation not started/stopped yet.
     */
    getFinishReason(): ChatCompletionFinishReason | undefined;
    getPolytheticFinishReason(): PolytheticGenerationFinishReason | undefined;
    /**
     * @returns tokenLogprobArray for this current round of autoregressive generation.
     * Updated upon each sampled token, cleared upon each prefillStep().
     */
    getTokenLogprobArray(): Array<ChatCompletionTokenLogprob>;
    /**
     * @returns the number of tokens decoded for a single request or a single choice in the request.
     */
    getCurRoundDecodingTotalTokens(): number;
    getCurRoundPolytheticCompletionTokens(): number;
    /**
     * @returns the number of tokens decoded for a single request or a single choice in the request.
     */
    getCurRoundPrefillTotalTokens(): number;
    /**
     * @returns the time spent on decode for a single request or a single choice in the request.
     */
    getCurRoundDecodingTotalTime(): number;
    /**
     * @returns the time spent on  for a single request or a single choice in the request.
     */
    getCurRoundPrefillTotalTime(): number;
    /**
     * @returns the time (seconds) spent on for initializing grammar matcher for a single request.
     */
    getCurRoundGrammarInitTotalTime(): number;
    /**
     * @returns the total time (seconds) spent on creating bitmask and accepting token grammar matcher
     * for all the generated tokens in a single request.
     */
    getCurRoundGrammarPerTokenTotalTime(): number;
    /**
     * @returns the breakdown of latencies for sampling each token for a single request.
     */
    getCurRoundLatencyBreakdown(): LatencyBreakdown;
    /**
     * @returns Runtime stats information.
     */
    runtimeStatsText(): string;
    /**
     * @returns Runtime stats information, starting from the last prefill performed.
     */
    curRoundRuntimeStatsText(): string;
    /**
     * @returns Prefill tokens per second, starting from the last prefill performed.
     */
    getCurRoundPrefillTokensPerSec(): number;
    /**
     * @returns Prefill tokens per second, starting from the last prefill performed.
     */
    getCurRoundDecodingTokensPerSec(): number;
    /**
     * Set the seed for the RNG `this.tvm.rng`.
     */
    setSeed(seed: number): void;
    private getResponseFormatKey;
    /**
     * @returns The conversation object (not a deep copy).
     */
    getConversationObject(): Conversation;
    /**
     * Set this.conversation to a new conversation object.
     */
    setConversation(newConv: Conversation): void;
    asyncLoadWebGPUPipelines(): Promise<void>;
    /**
     * Generate the first token given input prompt
     */
    prefillStep(inp: string, msgRole: Role, inp_role_str?: string, genConfig?: GenerationConfig): Promise<void>;
    decodeStep(genConfig?: GenerationConfig): Promise<void>;
    /**
     * Manually trigger stop if it is not stopped.
     */
    triggerStop(): void;
    /**
     * Add a generated token and check for stop.
     *
     * @param nextToken The next token.
     * @param genConfig Configs that override `this.config` for this round of generation.
     */
    private processNextToken;
    /**
     * Given input tokens, return embeddings of them by calling embed kernel.
     *
     * @note precondition: inputTokens.length <= prefillChunkSize, since we take care of
     * chunking in `getChunkedPrefillInputData()`.
     */
    private getTokensEmbeddings;
    /**
     * Compute the number of embedding tokens an image will produce.
     * Must match the model's image_embed output size.
     * Based on mlc_llm/serve/data.py _compute_embed_size.
     */
    private computeImageEmbedSize;
    /**
     * Calculate resize dimensions per model type.
     * Based on vlm_utils.cc CalculateResizeShape
     */
    private calculateResizeShape;
    /**
     * Calculate crop dimensions per model type.
     * Based on vlm_utils.cc CalculateCropShape / CalculatePadShape
     */
    private calculateCropShape;
    /**
     * Embed an image input.
     */
    private getImageEmbeddings;
    /**
     * Embed and forward input data, that can be either array of tokens, or an image.
     * This will increment `this.filledKVCacheLength`.
     *
     * @param inputData data to embed and forward
     * @param inputDataLen length of this inputData, should smaller than prefill chunk size.
     * @returns The logits returned by this forward as tvmjs.Tensor on GPU.
     *
     * @note Precondition: inputData's data length is smaller than prefill chunk size
     */
    private embedAndForward;
    private static loadVMFunctionRegistry;
    private static applyLegacyPolytheticAliases;
    private static getRequiredVMFunctionByName;
    private static getVMFunctionAvailability;
    private parseKVStateKind;
    private static resolveModelABI;
    private requireKVCache;
    private requireRNNState;
    private getSingleStateForABI;
    private getActiveKVStates;
    private resetPolytheticCaptureState;
    private capturePolytheticTokenChunk;
    private capturePolytheticRankOneTokenChunkV1;
    private invokePolytheticCapture;
    private invokePolytheticRankOneCaptureV1;
    private invokePrefill;
    private invokeDecode;
    private getPolytheticForwardArguments;
    private getPolytheticGeometryArguments;
    private updateLogitsOnCPU;
    private sampleTokenFromLogits;
    private commitSampledToken;
    /**
     * Return the an array of a mixture of token arrays and imageURLs (which cannot be represented
     * as tokens). Also return the number of tokens this represents.
     *
     * We first convert the Conversation into a prompt array to be prefilled. Then we encode the
     * text parts, leaving the imageURLs as it is.
     * Example prompts:
     * [
     *   "<|system|>\nSome system prompt\n",
     *   [
     *     "<|user|>\n",
     *     imageURL1,
     *     "\n",
     *     imageURL2,
     *     "\n",
     *     "Some user input<|end|>\n"
     *   ],
     * ]
     *
     * Expected output:
     * [
     *   token array for "<|system|>\nSome system prompt\n<|user|>\n",
     *   imageUrl1,
     *   token array for "\n",
     *   imageUrl2,
     *   token array for "\nSome user input<|end|>\n"
     */
    private getInputData;
    forwardTokensAndSample(inputIds: Array<number>, isPrefill: boolean): Promise<number>;
    /**
     * Based on `emittedToken` and `this.logitsOnCPU`, which becomes a distribution after
     * calling `this.tvm.applySoftmaxWithTemperature()`, generate `ChatCompletionTokenLogprob` and
     * update `this.tokenLogprobArray`.
     *
     * @param emittedToken The token ID emitted after any Polythetic forced replay override.
     * @param top_logprobs Number of top tokens to include; `top_logprobs` in `ChatCompletionRequest`.
     *
     * @return The `ChatCompletionTokenLogprob` for this single autoregressive step.
     */
    private getTokenLogprob;
    /**
     * Synchronize the device.
     */
    sync(): Promise<void>;
    evaluate(): Promise<void>;
}
//# sourceMappingURL=llm_chat.d.ts.map